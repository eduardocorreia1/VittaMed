import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  Check, Sparkles, ShieldCheck, Clock, Smartphone, Infinity as InfinityIcon,
  Leaf, HeartPulse, Activity, Apple, Sunrise, Moon, Droplet, Flame,
  Star, ChevronDown, ArrowRight, Award,
} from "lucide-react";
import heroWoman from "@/assets/hero-woman.jpg";
import wellnessIllustration from "@/assets/wellness-illustration.jpg";
import resultsImg from "@/assets/results.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Protocolo VittaMed 7D™ — Leveza em 7 dias" },
      { name: "description", content: "Protocolo digital para mulheres reduzirem o inchaço, recuperarem a leveza e acelerarem resultados em 7 dias. Acesso imediato e garantia." },
      { property: "og:title", content: "Protocolo VittaMed 7D™" },
      { property: "og:description", content: "O método premium para reduzir o inchaço e recuperar a leveza em 7 dias." },
      { property: "og:type", content: "website" },
    ],
    links: [
      { rel: "canonical", href: "/" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=Inter:wght@300;400;500;600;700&display=swap" },
    ],
  }),
  component: LandingPage,
});

function Logo({ light = false }: { light?: boolean }) {
  const color = light ? "text-white" : "text-primary";
  return (
    <div className={`flex items-center gap-2 ${color}`}>
      <div className="relative flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
        <Leaf className="h-4 w-4 text-gold" />
      </div>
      <div className="leading-none">
        <div className="font-display text-xl tracking-tight">VittaMed<sup className="text-gold text-[10px] ml-0.5">®</sup></div>
        <div className="text-[10px] uppercase tracking-[0.2em] opacity-60">Saúde feminina</div>
      </div>
    </div>
  );
}

function Pill({ icon: Icon, children }: { icon: React.ElementType; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-border bg-white/70 backdrop-blur px-4 py-2 text-xs font-medium text-primary shadow-soft">
      <Icon className="h-3.5 w-3.5 text-gold" />
      {children}
    </span>
  );
}

function Countdown() {
  const [t, setT] = useState({ h: 11, m: 59, s: 59 });
  useEffect(() => {
    const id = setInterval(() => {
      setT((p) => {
        let { h, m, s } = p;
        s--;
        if (s < 0) { s = 59; m--; }
        if (m < 0) { m = 59; h--; }
        if (h < 0) { h = 23; }
        return { h, m, s };
      });
    }, 1000);
    return () => clearInterval(id);
  }, []);
  const Box = ({ v, l }: { v: number; l: string }) => (
    <div className="flex flex-col items-center">
      <div className="flex h-16 w-16 md:h-20 md:w-20 items-center justify-center rounded-2xl bg-primary text-primary-foreground font-display text-3xl md:text-4xl shadow-elevated">
        {String(v).padStart(2, "0")}
      </div>
      <span className="mt-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">{l}</span>
    </div>
  );
  return (
    <div className="flex items-center gap-3 md:gap-4">
      <Box v={t.h} l="Horas" /><span className="text-2xl text-gold">:</span>
      <Box v={t.m} l="Min" /><span className="text-2xl text-gold">:</span>
      <Box v={t.s} l="Seg" />
    </div>
  );
}

const problems = [
  { icon: Droplet, t: "Barriga constantemente inchada" },
  { icon: Activity, t: "Sensação de retenção de líquidos" },
  { icon: Flame, t: "Roupas ficando apertadas" },
  { icon: Sunrise, t: "Falta de energia durante o dia" },
  { icon: Apple, t: "Dietas que nunca funcionam" },
  { icon: HeartPulse, t: "Baixa autoestima ao se olhar no espelho" },
];

const days = [
  { d: "Dia 1", t: "Despertar do corpo", desc: "Eliminação do excesso de líquidos e ajuste da hidratação.", icon: Droplet },
  { d: "Dia 2", t: "Reset alimentar", desc: "Reorganização do prato com alimentos anti-inflamatórios.", icon: Apple },
  { d: "Dia 3", t: "Leveza intestinal", desc: "Estímulo natural ao trânsito intestinal e digestão.", icon: Leaf },
  { d: "Dia 4", t: "Energia em alta", desc: "Combinações alimentares que devolvem a vitalidade.", icon: Sunrise },
  { d: "Dia 5", t: "Redução do inchaço", desc: "Rituais que combatem a retenção de líquidos.", icon: Activity },
  { d: "Dia 6", t: "Recomposição", desc: "Ajustes finos no metabolismo e descanso reparador.", icon: Moon },
  { d: "Dia 7", t: "Resultados visíveis", desc: "Avaliação dos ganhos e plano de continuidade.", icon: Award },
];

const benefits = [
  "Estratégias práticas validadas",
  "Plano simples de seguir no dia a dia",
  "Receitas fáceis e saborosas",
  "Organização alimentar descomplicada",
  "Orientações para reduzir o inchaço",
  "Hábitos que favorecem o emagrecimento",
];

const testimonials = [
  { n: "Mariana, 34", c: "Em 7 dias me senti mais leve, voltei a vestir minha calça favorita. O método é simples e cabe na minha rotina.", r: 5 },
  { n: "Camila, 41", c: "O inchaço sumiu, minha barriga ficou visivelmente menor. E o melhor: sem sofrer com dietas malucas.", r: 5 },
  { n: "Juliana, 29", c: "Finalmente algo que funciona. A energia voltou e o humor melhorou junto. Recomendo de olhos fechados.", r: 5 },
];

const faq = [
  { q: "Funciona para qualquer idade?", a: "Sim. O protocolo foi pensado para mulheres adultas em diferentes fases da vida, com adaptações simples conforme a rotina." },
  { q: "Preciso fazer academia?", a: "Não. O método é focado em hábitos diários e alimentação. Movimento é bem-vindo, mas não obrigatório." },
  { q: "Quanto tempo preciso dedicar por dia?", a: "Em média 15 a 20 minutos por dia para aplicar os rituais propostos." },
  { q: "Como recebo o acesso?", a: "Logo após a confirmação do pagamento você recebe o acesso por e-mail e na área de membros." },
  { q: "O acesso é imediato?", a: "Sim, o acesso é liberado imediatamente após a compra." },
  { q: "Posso acessar pelo celular?", a: "Sim. A plataforma é 100% responsiva — celular, tablet ou computador." },
];

function LandingPage() {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* NAV */}
      <header className="sticky top-0 z-50 border-b border-border/60 bg-white/80 backdrop-blur-md">
        <div className="container-x flex items-center justify-between py-4">
          <Logo />
          <a href="#oferta" className="hidden md:inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground transition hover:bg-primary/90">
            Começar agora <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </header>

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_oklch(0.95_0.04_145/0.6),_transparent_60%)]" />
        <div className="container-x relative grid gap-12 py-16 md:py-24 lg:grid-cols-2 lg:items-center">
          <div className="animate-fade-up">
            <div className="flex flex-wrap gap-2 mb-6">
              <Pill icon={Sparkles}>Acesso imediato</Pill>
              <Pill icon={Smartphone}>Método digital</Pill>
              <Pill icon={ShieldCheck}>Garantia de 7 dias</Pill>
            </div>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl leading-[1.05] text-primary">
              Descubra o protocolo que está ajudando mulheres a <em className="text-sage not-italic">reduzir o inchaço</em>, recuperar a leveza e acelerar resultados em apenas <span className="text-gold">7 dias</span>.
            </h1>
            <p className="mt-6 text-lg text-muted-foreground max-w-xl leading-relaxed">
              Um método simples e prático para mulheres que desejam voltar a se sentir bem com o próprio corpo — sem dietas extremas ou horas de academia.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4 items-start sm:items-center">
              <a href="#oferta" className="btn-primary btn-primary-hover w-full sm:w-auto">
                QUERO COMEÇAR AGORA <ArrowRight className="h-4 w-4" />
              </a>
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <div className="flex">{[0,1,2,3,4].map(i => <Star key={i} className="h-4 w-4 fill-gold text-gold" />)}</div>
                <span className="ml-2">+12.000 mulheres atendidas</span>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-6 -z-10 rounded-[3rem] bg-gradient-to-br from-sage/20 to-gold/10 blur-2xl" />
            <div className="relative overflow-hidden rounded-[2.5rem] shadow-elevated">
              <img src={heroWoman} alt="Mulher saudável e confiante após o Protocolo VittaMed 7D" width={1080} height={1600} className="h-[560px] w-full object-cover" />
            </div>
            <div className="absolute -bottom-6 -left-6 rounded-2xl bg-white p-4 shadow-elevated max-w-[220px] animate-float">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-gold"><HeartPulse className="h-5 w-5" /></div>
                <div>
                  <div className="text-xs text-muted-foreground">Resultados em</div>
                  <div className="font-display text-primary text-lg leading-none">7 dias</div>
                </div>
              </div>
            </div>
            <div className="absolute -top-4 -right-4 rounded-2xl bg-primary p-4 text-primary-foreground shadow-elevated">
              <div className="text-[10px] uppercase tracking-[0.2em] text-gold">Aprovado por</div>
              <div className="font-display text-lg">+12.000 mulheres</div>
            </div>
          </div>
        </div>
      </section>

      {/* TRUST BAR */}
      <section className="border-y border-border bg-cream">
        <div className="container-x py-6 flex flex-wrap items-center justify-around gap-6 text-xs uppercase tracking-[0.25em] text-muted-foreground">
          <span className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-sage" /> Compra 100% segura</span>
          <span className="flex items-center gap-2"><InfinityIcon className="h-4 w-4 text-sage" /> Acesso vitalício</span>
          <span className="flex items-center gap-2"><Smartphone className="h-4 w-4 text-sage" /> 100% digital</span>
          <span className="flex items-center gap-2"><Award className="h-4 w-4 text-sage" /> Método VittaMed®</span>
        </div>
      </section>

      {/* PROBLEMAS */}
      <section className="py-20 md:py-28">
        <div className="container-x">
          <div className="max-w-2xl mx-auto text-center mb-14">
            <div className="text-xs uppercase tracking-[0.25em] text-sage mb-3">Diagnóstico</div>
            <h2 className="font-display text-4xl md:text-5xl text-primary">Você se identifica com alguma dessas situações?</h2>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {problems.map(({ icon: Icon, t }) => (
              <div key={t} className="group rounded-3xl border border-border bg-card p-7 shadow-soft transition hover:shadow-elevated hover:-translate-y-1">
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-accent text-primary group-hover:bg-primary group-hover:text-gold transition">
                  <Icon className="h-5 w-5" />
                </div>
                <p className="text-lg text-foreground leading-snug">{t}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BIG IDEA */}
      <section className="bg-cream py-20 md:py-28">
        <div className="container-x grid gap-12 lg:grid-cols-2 lg:items-center">
          <div className="relative">
            <div className="overflow-hidden rounded-[2.5rem] bg-white shadow-soft">
              <img src={wellnessIllustration} alt="Folhas e elementos naturais que representam o protocolo" width={1200} height={900} loading="lazy" className="w-full h-auto" />
            </div>
          </div>
          <div>
            <div className="text-xs uppercase tracking-[0.25em] text-sage mb-3">A verdade</div>
            <h2 className="font-display text-4xl md:text-5xl text-primary leading-tight">O problema pode não ser apenas o excesso de peso.</h2>
            <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
              Muitas mulheres sofrem em silêncio com sintomas que vão muito além da balança. O corpo manifesta sinais que indicam algo mais profundo:
            </p>
            <ul className="mt-6 space-y-3">
              {["Retenção de líquidos", "Inflamação corporal silenciosa", "Maus hábitos diários acumulados", "Rotina alimentar desorganizada"].map(i => (
                <li key={i} className="flex items-start gap-3">
                  <div className="mt-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-gold flex-shrink-0">
                    <Check className="h-3 w-3" />
                  </div>
                  <span className="text-foreground">{i}</span>
                </li>
              ))}
            </ul>
            <p className="mt-6 text-lg text-foreground font-medium">
              O <span className="text-primary">Protocolo VittaMed 7D™</span> foi criado para auxiliar você a transformar esses hábitos, dia após dia.
            </p>
          </div>
        </div>
      </section>

      {/* COMO FUNCIONA */}
      <section className="py-20 md:py-28">
        <div className="container-x">
          <div className="max-w-2xl mx-auto text-center mb-16">
            <div className="text-xs uppercase tracking-[0.25em] text-sage mb-3">O método</div>
            <h2 className="font-display text-4xl md:text-5xl text-primary">Como funciona o Protocolo VittaMed 7D™</h2>
            <p className="mt-4 text-muted-foreground">Uma jornada guiada de 7 dias, construída para entregar resultados visíveis com simplicidade.</p>
          </div>
          <div className="relative">
            <div className="absolute left-1/2 top-0 hidden h-full w-px -translate-x-1/2 bg-gradient-to-b from-transparent via-gold/40 to-transparent lg:block" />
            <div className="space-y-10">
              {days.map((day, i) => (
                <div key={day.d} className={`grid gap-6 lg:grid-cols-2 lg:items-center ${i % 2 ? "lg:[&>*:first-child]:order-2" : ""}`}>
                  <div className="relative rounded-3xl border border-border bg-card p-8 shadow-soft">
                    <div className="absolute -top-3 left-8 rounded-full bg-gradient-to-r from-gold to-[#B8941F] px-4 py-1 text-xs font-semibold uppercase tracking-widest text-gold-foreground">{day.d}</div>
                    <div className="mt-3 flex items-start gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary text-gold flex-shrink-0">
                        <day.icon className="h-5 w-5" />
                      </div>
                      <div>
                        <h3 className="font-display text-2xl text-primary">{day.t}</h3>
                        <p className="mt-2 text-muted-foreground leading-relaxed">{day.desc}</p>
                      </div>
                    </div>
                  </div>
                  <div className="hidden lg:flex justify-center">
                    <div className="flex h-20 w-20 items-center justify-center rounded-full border-2 border-gold bg-cream font-display text-2xl text-primary shadow-elevated">
                      {i + 1}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* BENEFÍCIOS */}
      <section className="bg-primary text-primary-foreground py-20 md:py-28">
        <div className="container-x">
          <div className="max-w-2xl mb-14">
            <div className="text-xs uppercase tracking-[0.25em] text-gold mb-3">Conteúdo</div>
            <h2 className="font-display text-4xl md:text-5xl">O que você vai encontrar</h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {benefits.map(b => (
              <div key={b} className="flex items-start gap-4 rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur transition hover:bg-white/10">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gold text-primary flex-shrink-0">
                  <Check className="h-4 w-4" strokeWidth={3} />
                </div>
                <span className="text-lg leading-snug">{b}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* RESULTADOS */}
      <section className="py-20 md:py-28">
        <div className="container-x">
          <div className="max-w-2xl mx-auto text-center mb-14">
            <div className="text-xs uppercase tracking-[0.25em] text-sage mb-3">Resultados reais</div>
            <h2 className="font-display text-4xl md:text-5xl text-primary">Mulheres que decidiram começar</h2>
          </div>
          <div className="overflow-hidden rounded-[2.5rem] shadow-elevated mb-10">
            <img src={resultsImg} alt="Antes e depois de mulheres no Protocolo VittaMed 7D" width={1400} height={900} loading="lazy" className="w-full" />
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {testimonials.map(t => (
              <figure key={t.n} className="rounded-3xl border border-border bg-card p-7 shadow-soft">
                <div className="flex mb-3">{Array.from({ length: t.r }).map((_, i) => <Star key={i} className="h-4 w-4 fill-gold text-gold" />)}</div>
                <blockquote className="text-foreground leading-relaxed">"{t.c}"</blockquote>
                <figcaption className="mt-4 flex items-center gap-3 pt-4 border-t border-border">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-sage/20 text-primary font-display text-lg">{t.n[0]}</div>
                  <div>
                    <div className="font-medium text-primary">{t.n}</div>
                    <div className="text-xs text-muted-foreground">Cliente verificada</div>
                  </div>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* PROVAS SOCIAIS */}
      <section className="bg-cream py-20 md:py-28">
        <div className="container-x">
          <div className="max-w-2xl mx-auto text-center mb-14">
            <div className="text-xs uppercase tracking-[0.25em] text-sage mb-3">Comunidade</div>
            <h2 className="font-display text-4xl md:text-5xl text-primary">O que estão comentando</h2>
          </div>
          <div className="columns-1 md:columns-2 lg:columns-3 gap-6 [column-fill:_balance]">
            {[
              { n: "Patrícia M.", c: "Recomendo demais! Em uma semana minha disposição mudou completamente.", r: 5 },
              { n: "Renata S.", c: "Pensei que seria mais um. Mas o passo a passo é tão claro que dá pra seguir sem esforço.", r: 5 },
              { n: "Luana A.", c: "Perdi 2,3 kg de líquidos retidos. Estou amando o resultado.", r: 5 },
              { n: "Fernanda B.", c: "O melhor investimento que fiz pra mim. Vale cada centavo.", r: 5 },
              { n: "Aline C.", c: "Minha barriga desinchou e meu humor melhorou junto. Surpreendente.", r: 5 },
              { n: "Beatriz D.", c: "Receitas práticas, gostosas e fáceis. Marido também aprovou!", r: 5 },
            ].map((t, i) => (
              <div key={i} className="mb-6 break-inside-avoid rounded-2xl border border-border bg-white p-6 shadow-soft">
                <div className="flex items-center gap-3 mb-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-gold font-display">{t.n[0]}</div>
                  <div>
                    <div className="text-sm font-medium text-primary">{t.n}</div>
                    <div className="flex">{Array.from({ length: t.r }).map((_, j) => <Star key={j} className="h-3 w-3 fill-gold text-gold" />)}</div>
                  </div>
                </div>
                <p className="text-sm text-foreground leading-relaxed">{t.c}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* OFERTA */}
      <section id="oferta" className="py-20 md:py-28">
        <div className="container-x">
          <div className="relative overflow-hidden rounded-[2.5rem] bg-primary p-8 md:p-14 text-primary-foreground shadow-elevated">
            <div className="absolute -top-20 -right-20 h-72 w-72 rounded-full bg-gold/20 blur-3xl" />
            <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-sage/30 blur-3xl" />
            <div className="relative grid gap-10 lg:grid-cols-2 lg:items-center">
              <div>
                <div className="inline-flex items-center gap-2 rounded-full border border-gold/40 bg-gold/10 px-4 py-1.5 text-xs uppercase tracking-[0.2em] text-gold">
                  <Sparkles className="h-3.5 w-3.5" /> Oferta Especial
                </div>
                <h2 className="mt-5 font-display text-4xl md:text-5xl leading-tight">
                  Comece sua transformação <em className="text-gold not-italic">hoje mesmo</em>.
                </h2>
                <p className="mt-4 text-primary-foreground/80 max-w-md">
                  Tudo o que você precisa para reduzir o inchaço, recuperar a leveza e voltar a se sentir bem com o próprio corpo.
                </p>
                <div className="mt-8">
                  <div className="text-xs uppercase tracking-[0.25em] text-gold mb-3">A oferta expira em</div>
                  <Countdown />
                </div>
              </div>

              <div className="rounded-3xl bg-white text-foreground p-8 shadow-elevated">
                <div className="text-center">
                  <div className="text-sm uppercase tracking-[0.2em] text-sage">Protocolo VittaMed 7D™</div>
                  <div className="mt-3 flex items-center justify-center gap-3">
                    <span className="text-muted-foreground line-through">R$ 89,90</span>
                    <span className="rounded-full bg-gold/20 px-2 py-0.5 text-xs font-semibold text-primary">-78%</span>
                  </div>
                  <div className="mt-2 flex items-baseline justify-center gap-1">
                    <span className="text-2xl text-primary">R$</span>
                    <span className="font-display text-7xl text-primary">19,</span>
                    <span className="font-display text-4xl text-primary">90</span>
                  </div>
                  <div className="text-xs text-muted-foreground">pagamento único · sem mensalidades</div>
                </div>

                <ul className="mt-8 space-y-3">
                  {[
                    { i: InfinityIcon, t: "Acesso vitalício" },
                    { i: Sparkles, t: "Atualizações futuras gratuitas" },
                    { i: ShieldCheck, t: "Garantia incondicional de 7 dias" },
                    { i: Smartphone, t: "Acesso por celular, tablet ou computador" },
                  ].map(({ i: I, t }) => (
                    <li key={t} className="flex items-center gap-3 text-sm">
                      <I className="h-4 w-4 text-sage" /> {t}
                    </li>
                  ))}
                </ul>

                <a href="#" className="btn-primary btn-primary-hover mt-8 w-full text-base">
                  QUERO ACESSAR AGORA <ArrowRight className="h-4 w-4" />
                </a>
                <div className="mt-4 flex items-center justify-center gap-2 text-xs text-muted-foreground">
                  <ShieldCheck className="h-3.5 w-3.5" /> Compra 100% segura · SSL
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* GARANTIA */}
      <section className="bg-cream py-20 md:py-28">
        <div className="container-x">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mx-auto mb-8 flex h-32 w-32 items-center justify-center">
              <div className="relative flex h-32 w-32 items-center justify-center rounded-full border-2 border-gold bg-white shadow-elevated">
                <div className="absolute inset-2 rounded-full border border-gold/40" />
                <div className="text-center">
                  <ShieldCheck className="mx-auto h-8 w-8 text-gold" />
                  <div className="font-display text-primary text-lg leading-none mt-1">7 dias</div>
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Garantia</div>
                </div>
              </div>
            </div>
            <div className="text-xs uppercase tracking-[0.25em] text-sage mb-3">Risco Zero</div>
            <h2 className="font-display text-4xl md:text-5xl text-primary">Sua satisfação garantida</h2>
            <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
              Você terá 7 dias para conhecer o conteúdo. Se não ficar satisfeita, basta solicitar o reembolso dentro do prazo — devolvemos 100% do seu investimento, sem perguntas.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 md:py-28">
        <div className="container-x max-w-3xl">
          <div className="text-center mb-14">
            <div className="text-xs uppercase tracking-[0.25em] text-sage mb-3">Dúvidas frequentes</div>
            <h2 className="font-display text-4xl md:text-5xl text-primary">Perguntas frequentes</h2>
          </div>
          <div className="space-y-3">
            {faq.map((f, i) => {
              const open = openFaq === i;
              return (
                <div key={i} className="rounded-2xl border border-border bg-card shadow-soft overflow-hidden">
                  <button onClick={() => setOpenFaq(open ? null : i)} className="flex w-full items-center justify-between gap-4 p-6 text-left">
                    <span className="font-medium text-primary">{f.q}</span>
                    <ChevronDown className={`h-5 w-5 text-sage transition-transform ${open ? "rotate-180" : ""}`} />
                  </button>
                  {open && <div className="px-6 pb-6 text-muted-foreground leading-relaxed">{f.a}</div>}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="py-16">
        <div className="container-x">
          <div className="rounded-[2.5rem] bg-gradient-to-br from-sage/20 to-gold/10 p-10 md:p-14 text-center">
            <h2 className="font-display text-3xl md:text-4xl text-primary max-w-2xl mx-auto">Sua versão mais leve está a 7 dias de distância.</h2>
            <a href="#oferta" className="btn-primary btn-primary-hover mt-8">
              QUERO COMEÇAR AGORA <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-primary text-primary-foreground">
        <div className="container-x py-14">
          <div className="grid gap-10 md:grid-cols-3">
            <div>
              <Logo light />
              <p className="mt-4 text-sm text-primary-foreground/70 max-w-xs leading-relaxed">
                Soluções digitais de bem-estar para mulheres que querem viver mais leves, com saúde e confiança.
              </p>
            </div>
            <div>
              <div className="text-xs uppercase tracking-[0.25em] text-gold mb-4">Institucional</div>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-gold transition">Termos de Uso</a></li>
                <li><a href="#" className="hover:text-gold transition">Política de Privacidade</a></li>
                <li><a href="#" className="hover:text-gold transition">Contato</a></li>
              </ul>
            </div>
            <div>
              <div className="text-xs uppercase tracking-[0.25em] text-gold mb-4">Atendimento</div>
              <p className="text-sm text-primary-foreground/70">contato@vittamed.com.br</p>
              <p className="text-sm text-primary-foreground/70 mt-1">Seg. a Sex. — 9h às 18h</p>
            </div>
          </div>
          <div className="mt-12 border-t border-white/10 pt-6 text-xs text-primary-foreground/60 leading-relaxed">
            <p className="mb-2">
              <strong className="text-primary-foreground/80">Aviso legal:</strong> Este produto não substitui acompanhamento profissional. Os resultados podem variar de pessoa para pessoa.
            </p>
            <p>© {new Date().getFullYear()} VittaMed®. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
